exports.port = 8080;
exports.email = 'wyicwx@gmail.com';
exports.siteName = 'nodeWeibo';
exports.siteDesc = '一个用nodejs写的微博';

